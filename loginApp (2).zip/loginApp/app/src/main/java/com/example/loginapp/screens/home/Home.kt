package com.example.loginapp.screens.home

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.loginapp.R
import com.example.loginapp.databinding.ActivityHomeBinding

class Home:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding=DataBindingUtil.setContentView<ActivityHomeBinding>(this, R.layout.activity_home)
        val x:String=binding.tv1.text.toString()
        val a=intent.extras
        val msg:String="$x,\n${a?.getBundle("args")?.getString("email","User")}\nHappy Learning :)"
        binding.tv1.text=msg
    }
}