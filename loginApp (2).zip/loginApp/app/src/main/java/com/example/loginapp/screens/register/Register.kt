package com.example.loginapp.screens.register
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.Icon
import androidx.appcompat.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import com.example.loginapp.R
import com.example.loginapp.databinding.ActivityRegisterBinding
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import java.net.PasswordAuthentication
import java.security.KeyStore

@Suppress("DEPRECATION")
class Register:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding=DataBindingUtil.setContentView<ActivityRegisterBinding>(this, R.layout.activity_register)
        binding.registerButton.setOnClickListener {
            if(validateFields(binding,binding.firstName,binding.lastName,binding.emailRegister,binding.phone,binding.passwordRegister,binding.confirmPassword)){
                AlertDialog.Builder(this).setMessage("Registration Successful :)").setPositiveButton(
                        "Okay", DialogInterface.OnClickListener { dialog, id ->
                            this.finish()
                        }).setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, id ->
                    dialog.cancel()
                }).setTitle("Registration").show()
            }
        }
        binding.seePassword.setOnClickListener {
            if(binding.passwordRegister.transformationMethod==null){
                binding.passwordRegister.transformationMethod=PasswordTransformationMethod()
            }
            else{
                binding.passwordRegister.transformationMethod=null
            }
        }
        binding.seeConfirmPassword.setOnClickListener {
            if(binding.confirmPassword.transformationMethod==null){
                binding.confirmPassword.transformationMethod=PasswordTransformationMethod()
            }
            else{
                binding.confirmPassword.transformationMethod=null
            }
        }

    }

    private fun validateFields(
            binding:ActivityRegisterBinding,
            firstName:TextInputEditText,
            lastName:TextInputEditText,
            email:TextInputEditText,
            phone:TextInputEditText,
            password:TextInputEditText,
            confirmPassword:TextInputEditText): Boolean {
        val countOfEmptyFields=countNullFields(arrayListOf(firstName.text.toString(),lastName.text.toString(),email.text.toString(),phone.text.toString(),password.text.toString(),confirmPassword.text.toString()))
        if(countOfEmptyFields>=2){
            Snackbar.make(binding.registerConstraintLayout,"Please enter all the fields",Snackbar.LENGTH_LONG)
                    .setBackgroundTint(Color.parseColor("#C70039")).setTextColor(Color.WHITE).show()
            return false
        }
        else if(countOfEmptyFields==1){
                if(firstName.text.toString()=="") {
                    Snackbar.make(binding.registerConstraintLayout,"Please enter your First Name",Snackbar.LENGTH_LONG)
                            .setBackgroundTint(Color.parseColor("#C70039")).setTextColor(Color.WHITE).show()
                    return false
                }
                if(lastName.text.toString()=="") {
                    Snackbar.make(binding.registerConstraintLayout,"Please enter your Last Name",Snackbar.LENGTH_LONG)
                            .setBackgroundTint(Color.parseColor("#C70039")).setTextColor(Color.WHITE).show()
                    return false
                }
                if(email.text.toString()==""){
                    Snackbar.make(binding.registerConstraintLayout,"Please enter your Email",Snackbar.LENGTH_LONG)
                            .setBackgroundTint(Color.parseColor("#C70039")).setTextColor(Color.WHITE).show()
                    return false
                }
                if(phone.text.toString()=="") {
                    Snackbar.make(binding.registerConstraintLayout,"Please enter your Phone Number",Snackbar.LENGTH_LONG)
                            .setBackgroundTint(Color.parseColor("#C70039")).setTextColor(Color.WHITE).show()
                    return false
                }
                if(password.text.toString()==""){
                    Snackbar.make(binding.registerConstraintLayout,"Please enter a Password",Snackbar.LENGTH_LONG)
                            .setBackgroundTint(Color.parseColor("#C70039")).setTextColor(Color.WHITE).show()
                    return false
                }
                if(confirmPassword.text.toString()==""){
                    Snackbar.make(binding.registerConstraintLayout,"Please confirm your Password",Snackbar.LENGTH_LONG)
                            .setBackgroundTint(Color.parseColor("#C70039")).setTextColor(Color.WHITE).show()
                    return false
                }
            return false
        }
        else if(countOfEmptyFields==0){
            if(email.text!=null){
                if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email.text.toString()).matches()){
                    Snackbar.make(binding.registerConstraintLayout,"Please enter a valid Email Address",Snackbar.LENGTH_LONG)
                            .setBackgroundTint(Color.parseColor("#C70039")).setTextColor(Color.WHITE).show()
                    return false
                }
            }
            if(phone.text.toString().length < 10){
                Snackbar.make(binding.registerConstraintLayout,"Phone number must have 10 digits only",Snackbar.LENGTH_LONG)
                        .setBackgroundTint(Color.parseColor("#C70039")).setTextColor(Color.WHITE).show()
                return false
            }
            if(password.text.toString().length <6){
                Snackbar.make(binding.registerConstraintLayout,"Please enter a stronger Password",Snackbar.LENGTH_LONG)
                        .setBackgroundTint(Color.parseColor("#C70039")).setTextColor(Color.WHITE).show()
                return false
            }
            if(confirmPassword.text.toString()!=password.text.toString()){
                Snackbar.make(binding.registerConstraintLayout,"Please reconfirm your Password",Snackbar.LENGTH_LONG)
                        .setBackgroundTint(Color.parseColor("#C70039")).setTextColor(Color.WHITE).show()
                return false
            }
            return true
        }
        return false
    }

    private fun countNullFields(array: ArrayList<String>):Int{
        var count=0
        for(x:String in array){
            if(x==null || x==""){
                count++
            }
        }
        return count
    }
}