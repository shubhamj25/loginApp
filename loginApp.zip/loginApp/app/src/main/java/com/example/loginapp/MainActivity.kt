package com.example.loginapp
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.loginapp.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding=DataBindingUtil.setContentView<ActivityMainBinding>(
            this,
            R.layout.activity_main
        )
        binding.forgotPassword.setOnClickListener{
            val i=Intent(this@MainActivity, ForgotPassword::class.java)
            startActivity(i)
        }

        binding.loginButton.setOnClickListener {
            val x:Boolean= checkEmail(binding.email.text.toString())
            val y:Boolean =checkPassword(binding.password.text.toString())
            if( x&&y ){
                val intent= Intent(this@MainActivity, Home::class.java)
                val bundle=Bundle()
                bundle.putString("email", binding.email.text.toString())
                intent.putExtra("args", bundle)
                AlertDialog.Builder(this).setMessage("LogIn Successful :)").setPositiveButton(
                    "Okay",
                    DialogInterface.OnClickListener { dialog, id ->
                        startActivity(
                            intent
                        )
                    }).setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, id ->
                    dialog.cancel()
                }).setTitle("Welcome to Android").show()
                //Snackbar.make(binding.constraintLayout,"LogIn Successful :)",Snackbar.LENGTH_INDEFINITE).setBackgroundTint(Color.parseColor("#2ECC71")).setAction("Okay",View.OnClickListener { }).setTextColor(Color.WHITE).show()
            }
            else{
               if(!x){
                   Snackbar.make(
                       binding.constraintLayout,
                       "Please enter a valid email !",
                       Snackbar.LENGTH_LONG
                   ).setBackgroundTint(Color.parseColor("#C70039")).setTextColor(Color.WHITE).show()
               }
                else if(!y){
                   Snackbar.make(
                       binding.constraintLayout,
                       "Please enter a password of atleast 8 characters",
                       Snackbar.LENGTH_LONG
                   ).setBackgroundTint(Color.parseColor("#C70039")).setTextColor(Color.WHITE).show()
               }
            }
        }
    }

    private fun checkEmail(email: String): Boolean {
        if(email!=null && email.contains('@')){
            return true
        }
        return false
    }

    private fun checkPassword(password: String): Boolean {
        if(password!=null && password.length >=8){
            return true
        }
        return false
    }
}